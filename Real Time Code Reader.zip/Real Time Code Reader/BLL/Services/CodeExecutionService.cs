﻿using System.Diagnostics;
using System.Text;
using DevMentorAI.API.Models;

namespace DevMentorAI.API.Services
{
    public class CodeExecutionService : ICodeExecutionService
    {
        private readonly ILogger<CodeExecutionService> _logger;
        private readonly string _tempDirectory;

        public CodeExecutionService(ILogger<CodeExecutionService> logger)
        {
            _logger = logger;
            _tempDirectory = Path.Combine(Path.GetTempPath(), "DevMentorAI");

            // Create temp directory if it doesn't exist
            if (!Directory.Exists(_tempDirectory))
            {
                Directory.CreateDirectory(_tempDirectory);
            }
        }

        public async Task<CodeExecutionResult> ExecuteCodeAsync(CodeExecutionRequest request)
        {
            var result = new CodeExecutionResult
            {
                Language = request.Language,
                ExecutedAt = DateTime.UtcNow
            };

            try
            {
                _logger.LogInformation($"Executing {request.Language} code");

                switch (request.Language.ToLower())
                {
                    case "python":
                        result = await ExecutePythonAsync(request.Code);
                        break;
                    case "javascript":
                        result = await ExecuteJavaScriptAsync(request.Code);
                        break;
                    case "csharp":
                        result = await ExecuteCSharpAsync(request.Code);
                        break;
                    default:
                        result.Success = false;
                        result.Error = $"Language '{request.Language}' is not supported for execution yet. Supported: Python, JavaScript, C#";
                        break;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error executing code");
                result.Success = false;
                result.Error = $"Execution error: {ex.Message}";
            }

            return result;
        }

        private async Task<CodeExecutionResult> ExecutePythonAsync(string code)
        {
            var result = new CodeExecutionResult { Language = "python" };
            var fileName = $"script_{Guid.NewGuid()}.py";
            var filePath = Path.Combine(_tempDirectory, fileName);

            try
            {
                // Write code to temp file
                await File.WriteAllTextAsync(filePath, code);

                // Execute Python
                var processInfo = new ProcessStartInfo
                {
                    FileName = "python",
                    Arguments = $"\"{filePath}\"",
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using var process = new Process { StartInfo = processInfo };
                var outputBuilder = new StringBuilder();
                var errorBuilder = new StringBuilder();

                process.OutputDataReceived += (sender, e) =>
                {
                    if (e.Data != null) outputBuilder.AppendLine(e.Data);
                };

                process.ErrorDataReceived += (sender, e) =>
                {
                    if (e.Data != null) errorBuilder.AppendLine(e.Data);
                };

                process.Start();
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();

                // Timeout after 10 seconds
                var completed = await Task.Run(() => process.WaitForExit(10000));

                if (!completed)
                {
                    process.Kill();
                    result.Success = false;
                    result.Error = "Execution timed out (10 seconds limit)";
                    return result;
                }

                result.Output = outputBuilder.ToString();
                result.Error = errorBuilder.ToString();
                result.ExitCode = process.ExitCode;
                result.Success = process.ExitCode == 0;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Error = $"Python execution failed: {ex.Message}. Make sure Python is installed and in PATH.";
            }
            finally
            {
                // Cleanup temp file
                if (File.Exists(filePath))
                {
                    try { File.Delete(filePath); } catch { }
                }
            }

            return result;
        }

        private async Task<CodeExecutionResult> ExecuteJavaScriptAsync(string code)
        {
            var result = new CodeExecutionResult { Language = "javascript" };
            var fileName = $"script_{Guid.NewGuid()}.js";
            var filePath = Path.Combine(_tempDirectory, fileName);

            try
            {
                // Write code to temp file
                await File.WriteAllTextAsync(filePath, code);

                // Execute Node.js
                var processInfo = new ProcessStartInfo
                {
                    FileName = "node",
                    Arguments = $"\"{filePath}\"",
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using var process = new Process { StartInfo = processInfo };
                var outputBuilder = new StringBuilder();
                var errorBuilder = new StringBuilder();

                process.OutputDataReceived += (sender, e) =>
                {
                    if (e.Data != null) outputBuilder.AppendLine(e.Data);
                };

                process.ErrorDataReceived += (sender, e) =>
                {
                    if (e.Data != null) errorBuilder.AppendLine(e.Data);
                };

                process.Start();
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();

                // Timeout after 10 seconds
                var completed = await Task.Run(() => process.WaitForExit(10000));

                if (!completed)
                {
                    process.Kill();
                    result.Success = false;
                    result.Error = "Execution timed out (10 seconds limit)";
                    return result;
                }

                result.Output = outputBuilder.ToString();
                result.Error = errorBuilder.ToString();
                result.ExitCode = process.ExitCode;
                result.Success = process.ExitCode == 0;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Error = $"Node.js execution failed: {ex.Message}. Make sure Node.js is installed and in PATH.";
            }
            finally
            {
                // Cleanup temp file
                if (File.Exists(filePath))
                {
                    try { File.Delete(filePath); } catch { }
                }
            }

            return result;
        }

        private async Task<CodeExecutionResult> ExecuteCSharpAsync(string code)
        {
            var result = new CodeExecutionResult { Language = "csharp" };

            try
            {
                // For C#, we use dotnet-script
                var fileName = $"script_{Guid.NewGuid()}.csx";
                var filePath = Path.Combine(_tempDirectory, fileName);

                await File.WriteAllTextAsync(filePath, code);

                var processInfo = new ProcessStartInfo
                {
                    FileName = "dotnet",
                    Arguments = $"script \"{filePath}\"",
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using var process = new Process { StartInfo = processInfo };
                var outputBuilder = new StringBuilder();
                var errorBuilder = new StringBuilder();

                process.OutputDataReceived += (sender, e) =>
                {
                    if (e.Data != null) outputBuilder.AppendLine(e.Data);
                };

                process.ErrorDataReceived += (sender, e) =>
                {
                    if (e.Data != null) errorBuilder.AppendLine(e.Data);
                };

                process.Start();
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();

                var completed = await Task.Run(() => process.WaitForExit(10000));

                if (!completed)
                {
                    process.Kill();
                    result.Success = false;
                    result.Error = "Execution timed out (10 seconds limit)";
                    return result;
                }

                result.Output = outputBuilder.ToString();
                result.Error = errorBuilder.ToString();
                result.ExitCode = process.ExitCode;
                result.Success = process.ExitCode == 0;

                // Cleanup
                if (File.Exists(filePath))
                {
                    try { File.Delete(filePath); } catch { }
                }
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Error = $"C# execution failed: {ex.Message}. Make sure dotnet-script is installed (dotnet tool install -g dotnet-script).";
            }

            return result;
        }
    }
}